import json
videos = json.loads('data.json')

years = set(videos.year)
months = []
for year in years:
    months.append(set(videos[videos['year'].isin([year])].month))