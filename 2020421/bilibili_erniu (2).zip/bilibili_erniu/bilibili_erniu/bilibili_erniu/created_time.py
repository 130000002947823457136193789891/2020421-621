from datetime import datetime
import json
videos = json.loads('data.json')

def change_time(t):
    return datetime.fromtimestamp(t).strftime('%Y-%m-%d %H:%M')


def split_date(t):
    return t.split(' ')[0]


def split_hour_min(t):
    return t.split(' ')[1]


videos['time'] = videos.created_time.apply(change_time)  # 时间戳转为年月日时分
videos['date'] = videos.time.apply(split_date)  # 分出日期
videos['hour_min'] = videos.time.apply(split_hour_min)  # 分出时间
videos['year'], videos['month'], videos['day'] = videos.date.str.split('-').str  # 年月日分开