import json
videos = json.loads('data.json')

videos.year = videos.year.astype('int')
videos.month = videos.month.astype('int')
videos.day = videos.day.astype('int')
videos.sort_values(['year', 'month', 'day'], inplace=True)