from pyecharts.charts import Scatter

c = (
    Scatter()
        .add_xaxis(list(videos_new.length))
        .add_yaxis("播放量", list(videos_new.play))
        .set_global_opts(
        title_opts=opts.TitleOpts(title="山药村二牛视频时长-播放量散点图"),
        visualmap_opts=opts.VisualMapOpts(type_="size", max_=1000000, min_=27000),
    )
)